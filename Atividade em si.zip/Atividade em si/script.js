//OBJETIVOS --> Pegar o que será escrito dentro do input
// --> Colocar dentro do array;
// --> apresentar em checkbox;

function AddObject(){
    let quemE_Digitado = document.getElementById("adicionar").value; //Pega o que foi digitado no input
    let quemE_Armazenado = [];//array

    if(quemE_Digitado == "") {
        alert("Você precisa escrever alguma coisa");

    }

    else {
        quemE_Armazenado.push(quemE_Digitado);//colocando o que foi digitado dentro do array

        // Posição de entrada de elementos;
        let elemento_PaidaCheck = document.getElementById("Addcheck"); //Referente a div que está no html;
        let elemento_Div_Pai = document.createElement("table");//tabela para adicionar a checkbox + o texto;
        let elemento_Div = document.createElement("tr"); // Tr para criar linhas na tabela;
        let cria_CheckBox = document.createElement("input");//Criação do input dentro do js
        let paragrafo = document.createElement("p");
        cria_CheckBox.setAttribute("type", "checkbox");//cria a check box ao apertar o botão;
        
        /*      Hierarquia de posicionamento de elementos -->
        *        
        *   Elemento_PaidaCheck > elemento_Div_Pai > elemento_Div > cria_CheckBox = paragrafo;
        * 
        *      Segue o código abaixo -->
        */      

        elemento_PaidaCheck.appendChild(elemento_Div_Pai);
        elemento_Div_Pai.appendChild(elemento_Div);
        elemento_Div.appendChild(cria_CheckBox);
        elemento_Div.appendChild(paragrafo);

        // Introdução das linhas da tabela;
        let tr = elemento_Div.insertRow(elemento_Div);
        
        //colocar a informação dentro do paragrafo;
        let introduzir = document.createTextNode(quemE_Armazenado);
        paragrafo.appendChild(introduzir);
             
        
    }

}


